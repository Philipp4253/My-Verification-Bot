"""FSM состояния для процесса верификации врачей."""

from .verification import VerificationStates

__all__ = [
    'VerificationStates',
]
